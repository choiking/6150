<?php # Script 6.1 - config.inc.php
// Set the level of error reporting.
error_reporting (E_ALL);
?>