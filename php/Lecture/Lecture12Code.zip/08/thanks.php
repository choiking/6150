<?php # Script 8.8 - thanks.php
$page_title = 'Thank You!';
include ('./includes/header.html');
?>
<h1 id="mainhead">Thank you!</h1>
<p>You are now registered. In Chapter 9--just around the corner--you will actually be able to log in!</p><p><br /></p>
<?php
include ('./includes/footer.html');
?>